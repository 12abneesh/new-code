## Deploying Application
### Overview

The following reference was borrowed for our deployment architecture
![image](https://user-images.githubusercontent.com/49879250/127520843-c244abdb-7e70-46ff-aa53-72dab5ebed0a.png)

As soon as there is a new commit to the main branch, the entire pipeline is running to deploy a new version of the applications. 

### How to Provision 
```
Prereq: VPC, Bastion, EKS already setup from the commands below
-------------------------------
cd infra/provision 
AUTO_APPROVE=true make vpc-tf-apply bastion-tf-apply
make bastion-authorize-all-ssh-keys bastion-init
AUTO_APPROVE=true make eks-tf-apply

What To Run
-----------
cd infra/deployment
make deploy-tf-apply
```

## How-to
1. Accessing to Bastion
```
  |2.6.2| C02Y80DDJGH7 in /Volumes/code/Alpha/infra/provision
±  |main ✓| → make bastion-shell
ssh ubuntu@35.84.110.16
Welcome to Ubuntu 20.04.2 LTS (GNU/Linux 5.8.0-1041-aws x86_64)

 * Documentation:  https://help.ubuntu.com
 * Management:     https://landscape.canonical.com
 * Support:        https://ubuntu.com/advantage

  System information as of Thu Jul 29 15:14:55 UTC 2021

  System load:  0.02              Processes:                114
  Usage of /:   35.1% of 9.63GB   Users logged in:          0
  Memory usage: 10%               IPv4 address for docker0: 172.17.0.1
  Swap usage:   0%                IPv4 address for ens5:    10.0.4.207

 * Super-optimized for small spaces - read how we shrank the memory
   footprint of MicroK8s to make it the smallest full K8s around.

   https://ubuntu.com/blog/microk8s-memory-optimisation

16 updates can be applied immediately.
11 of these updates are standard security updates.
To see these additional updates run: apt list --upgradable


Last login: Thu Jul 29 15:11:51 2021 from 52.201.106.253
ubuntu@ip-10-0-4-207:~$
```
2. Listing Codepipelines
```
±  |main ✓| → aws codepipeline list-pipelines
{
    "pipelines": [
        {
            "name": "example-dev-main-ci",
            "version": 1,
            "created": "2021-07-29T11:07:15.933000-04:00",
            "updated": "2021-07-29T11:07:15.933000-04:00"
        },
        {
            "name": "example-test-tedlee-eks-ci",
            "version": 4,
            "created": "2021-07-28T06:29:07.347000-04:00",
            "updated": "2021-07-28T18:42:49.768000-04:00"
        },
        {
            "name": "rebalancer-dev-main-ci",
            "version": 1,
            "created": "2021-07-29T11:11:13.583000-04:00",
            "updated": "2021-07-29T11:11:13.583000-04:00"
        },
        {
            "name": "rebalancer-test-tedlee-eks-ci",
            "version": 4,
            "created": "2021-07-28T06:29:07.269000-04:00",
            "updated": "2021-07-28T18:42:49.251000-04:00"
        },
        {
            "name": "widgetservice",
            "version": 1,
            "created": "2021-05-07T18:45:17.026000-04:00",
            "updated": "2021-05-07T18:45:17.026000-04:00"
        }
    ]
}
```
3. Trigger Codepipeline from CLI
```
  |2.6.2| C02Y80DDJGH7 in /Volumes/code/Alpha/infra/provision
±  |main ✓| → aws codepipeline start-pipeline-execution --name rebalancer-dev-main-ci
{
    "pipelineExecutionId": "9064cbcb-d671-47fc-8773-8293266ef381"
}
```
4. Running kubectl from Bastion
```
  |2.6.2| C02Y80DDJGH7 in /Volumes/code/Alpha/infra/provision
±  |main ✓| → make bastion-shell
ssh ubuntu@35.84.110.16
Welcome to Ubuntu 20.04.2 LTS (GNU/Linux 5.8.0-1041-aws x86_64)

 * Documentation:  https://help.ubuntu.com
 * Management:     https://landscape.canonical.com
 * Support:        https://ubuntu.com/advantage

  System information as of Thu Jul 29 15:18:33 UTC 2021

  System load:  0.0               Processes:                113
  Usage of /:   35.1% of 9.63GB   Users logged in:          0
  Memory usage: 10%               IPv4 address for docker0: 172.17.0.1
  Swap usage:   0%                IPv4 address for ens5:    10.0.4.207

 * Super-optimized for small spaces - read how we shrank the memory
   footprint of MicroK8s to make it the smallest full K8s around.

   https://ubuntu.com/blog/microk8s-memory-optimisation

16 updates can be applied immediately.
11 of these updates are standard security updates.
To see these additional updates run: apt list --upgradable


Last login: Thu Jul 29 15:14:56 2021 from 52.201.106.253
ubuntu@ip-10-0-4-207:~$ kubectl get all
NAME                           READY   STATUS      RESTARTS   AGE
pod/example-76b47f9fdb-f2f66   1/1     Running     0          7m20s
pod/example-76b47f9fdb-mgh2z   1/1     Running     0          7m20s
pod/example-76b47f9fdb-mjv7m   1/1     Running     0          7m20s
pod/rebalancer-92gk7           0/1     Completed   0          5m12s

NAME                 TYPE        CLUSTER-IP   EXTERNAL-IP   PORT(S)   AGE
service/kubernetes   ClusterIP   172.20.0.1   <none>        443/TCP   26m

NAME                      READY   UP-TO-DATE   AVAILABLE   AGE
deployment.apps/example   3/3     3            3           7m20s

NAME                                 DESIRED   CURRENT   READY   AGE
replicaset.apps/example-76b47f9fdb   3         3         3       7m20s

NAME                   COMPLETIONS   DURATION   AGE
job.batch/rebalancer   1/1           19s        5m12s
ubuntu@ip-10-0-4-207:~$
```

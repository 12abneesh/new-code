## Overview
The implementations under this directory try to demonstrate the ideas at https://addepar.atlassian.net/wiki/spaces/EN/pages/2457796695/WIP+Network+Topology. VPC is the top of the hierarchy in this plan. Makefile generates the AWS artifacts and components per environment including VPC. Each component has a tag derived from `$USER` environment variable in order to support per-user development to iterate the development cycle quickly until we finalize the production grade infrastructure plan. `$DEPLOY_ENV` environment variable indicates in which environment to use. By default, it is `dev`. For more environments, it is necessary to add directory and populate under `terraform/environment` to customize and run with the corresponding `$DEPLOY_ENV`.

## How to provision
First of all, the Terraform scripts here assume that you have your AWS credential in ~/.aws/credentials under `alpha-dev` profile. Configure this first unless you have done it.

### Step 1: VPC
```
make vpc-tf-apply
```

### Step 2: Bastion
```
make bastion-tf-apply
```

### Step 3: Authorize SSH Keys for the Bastion Server
The following command authorizes the public SSH keys under `config/ssh/authorized_keys` to access the Bastion server
```
make bastion-authorize-all-ssh-keys
```

### Step 4: Initialize the Bastion Server
```
make bastion-init
```

### Step 5: Login into the Bastion Server
You must be in the authorized network such as the corporate VPNs.
```
make bastion-shell
```

Because we are provisioning the data related components in private only network, we need to run Terraform apply from the Bastion server. Note that there will be changes to make it runnable from the local developer machine via the Bastion server. Until then, try this way. =)

### Step 6: Provision Route53 Private Hosted Zone
```
USER=<your user name> make route53-tf-apply
```

### Step 7: Provision EKS Cluster
```
cd /opt/Alpha.git/infra/provision
USER=<your user name> make eks-tf-apply
```

### Step 8: Provision RDS Cluster
```
cd /opt/Alpha.git/infra/provision
USER=<your user name> make rds-tf-apply
```

### Step 9: Provision RDS Cluster
```
cd /opt/Alpha.git/infra/provision
USER=<your user name> make rds-tf-apply
```

### Step 10: Provision MSK Cluster
```
cd /opt/Alpha.git/infra/provision
USER=<your user name> make msk-tf-apply
```

### Step 11: Provision SecretManager
Primarily responsible for RDS credential rotation and MSK Certifcate Rotation
```
cd /opt/Alpha.git/infra/provision
USER=<your user name> make secretmanager-tf-apply
```

## How to destroy
It basically the reverse of the provioning if a dependency exists.

From the Bastion Server
```
make msk-tf-destroy eks-tf-destroy rds-tf-destroy route53-tf-destroy
```

From non-bastion environment
```
make bastion-tf-destroy vpc-tf-destroy
```

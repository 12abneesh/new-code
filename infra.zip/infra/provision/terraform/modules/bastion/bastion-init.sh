#!/bin/bash -eux


log() {
    (set +x; printf '*** %s\t%s\n' "$(date -u +%FT%TZ)" "$1")
}

install_dependencies () {
    until sudo apt-get update; do sleep 5; done
    sudo apt-get install -y build-essential libssl-dev zlib1g-dev expect make docker.io atop iotop ioping iftop acl zip postgresql-client-common postgresql-client-12
    install_awscliv2
    install_kubectl
    install_aws_iam_authenticator
    install_jenv
    install_openjdk_11
    install_gradle
    install_certbot
    install_terraform
    install_pyenv
    install_pip
}

install_pip () {
    curl https://bootstrap.pypa.io/get-pip.py -o /tmp/get-pip.py && python3 /tmp/get-pip.py    
}

install_pyenv () {  
    curl https://pyenv.run | bash
    echo 'export PYENV_ROOT="$HOME/.pyenv"'       | tee -a ~/.bashrc
	echo 'export PATH="$PYENV_ROOT/bin:$PATH"'    | tee -a ~/.bashrc
    echo 'eval "$(pyenv init --path)"'           | tee -a ~/.bashrc
	echo 'eval "$(pyenv init -)"'                | tee -a ~/.bashrc
	echo 'eval "$(pyenv virtualenv-init -)"'     | tee -a ~/.bashrc
    source $HOME/.bashrc
}

install_awscliv2 () {
    curl "https://awscli.amazonaws.com/awscli-exe-linux-x86_64-2.0.30.zip" -o /tmp/awscliv2.zip
    cd /tmp/ && unzip awscliv2.zip
    sudo ./aws/install -i /usr/local/aws-cli -b /usr/local/bin --update
    rm -rf ./aws
}

install_kubectl () {
    echo 'export KUBECONFIG=$KUBECONFIG:~/.kube/config' >> ~/.bashrc
    curl -L "https://dl.k8s.io/release/$(curl -L -s https://dl.k8s.io/release/stable.txt)/bin/linux/amd64/kubectl" -o /tmp/kubectl
    sudo install -o root -g root -m 0755 /tmp/kubectl /usr/local/bin/kubectl
    kubectl version --client
    source $HOME/.bashrc
}

install_aws_iam_authenticator () {
    curl -o /tmp/aws-iam-authenticator https://amazon-eks.s3.us-west-2.amazonaws.com/1.19.6/2021-01-05/bin/linux/amd64/aws-iam-authenticator
    chmod +x /tmp/aws-iam-authenticator
    mkdir -p $HOME/bin && cp /tmp/aws-iam-authenticator $HOME/bin/aws-iam-authenticator
    echo "export PATH=$PATH:$HOME/bin" >> $HOME/.bashrc
}

install_openjdk_11 () {
    sudo add-apt-repository -y ppa:openjdk-r/ppa
    sudo apt-get update
    sudo apt install -y openjdk-11-jdk
    source $HOME/.bashrc
    mkdir $HOME/.jenv/versions
    $HOME/.jenv/bin/jenv add /usr/lib/jvm/java-11-openjdk-amd64
}

install_jenv () {
    git clone https://github.com/jenv/jenv.git ~/.jenv
    echo 'export PATH="$HOME/.jenv/bin:$PATH"' >> ~/.bashrc
    echo 'eval "$(jenv init -)"' >> ~/.bashrc
    source $HOME/.bashrc
}

install_gradle () {
    curl -fsSL https://services.gradle.org/distributions/gradle-7.1.1-bin.zip -o /tmp/gradle-7.1.1-bin.zip
    sudo mkdir /opt/gradle
    sudo unzip -d /opt/gradle /tmp/gradle-7.1.1-bin.zip
    echo 'export PATH="$PATH:/opt/gradle/gradle-7.1.1/bin"' >> ~/.bashrc
    source $HOME/.bashrc
}

install_certbot () {
    # installed as a snap, preferred: https://certbot.eff.org/lets-encrypt/ubuntufocal-nginx
    # https://community.letsencrypt.org/t/a-new-way-to-install-certbot-on-linux/120408
    sudo apt-get remove -y certbot
    sudo snap install --classic certbot
    sudo ln -s /snap/bin/certbot /usr/bin/certbot
    sudo apt-get install -y python3-certbot-nginx python3-certbot-dns-route53
}

install_terraform () {
    curl -fsSL https://releases.hashicorp.com/terraform/1.0.2/terraform_1.0.2_linux_amd64.zip -o /tmp/terraform_1.0.2_linux_amd64.zip
    cd /tmp/
    unzip terraform_1.0.2_linux_amd64.zip
    sudo mv terraform /usr/local/bin
}

cleanup_os_settings_init () {
    sudo apt-get clean
    sudo rm -rf /tmp/*
}

install_dependencies
cleanup_os_settings_init

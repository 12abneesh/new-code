## Overview
This credential rotation Lambda is provisioning from the Terraform script. But sometimes it is beneficial to use `sam` to build and test locally. `tempalte.yaml` is created here for the purpose.

In order to build and invoke the lambda, execute the below commands from the directory where `template.yaml` file exists

```
sam build && sam local invoke MainRdsCredentialRotationFunction
```

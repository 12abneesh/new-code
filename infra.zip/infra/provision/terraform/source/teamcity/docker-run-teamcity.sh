#!/bin/bash
trap 'echo "${BASH_SOURCE[0]}: line ${LINENO}: status ${?}: user ${USER}: func ${FUNCNAME[0]}"' ERR
set -o errexit
set -o errtrace

TEAMCITY_VOLUME_DATA="/mnt/volume/teamcity/datadir"
sudo mkdir -p ${TEAMCITY_VOLUME_DATA}

TEAMCITY_VOLUME_LOG="/mnt/volume/teamcity/logs"
sudo mkdir -p ${TEAMCITY_VOLUME_LOG}

sudo chown -R 1000:1000 ${TEAMCITY_VOLUME_DATA} ${TEAMCITY_VOLUME_LOG}

######################################################################
function install_deps {
    sudo apt-get update && sudo apt-get install -y build-essential libssl-dev zlib1g-dev expect make docker.io atop iotop ioping iftop acl zip
}

function docker_run_teamcity_server {
    sudo docker container run \
        --detach \
        --name teamcity-server-instance \
        --publish 8111:8111 \
        --mount type="bind",src=${TEAMCITY_VOLUME_DATA},dst="/data/teamcity_server/datadir" \
        --mount type="bind",src=${TEAMCITY_VOLUME_LOG},dst="/opt/teamcity/logs" \
        jetbrains/teamcity-server
}

######################################################################

install_deps
docker_run_teamcity_server
#!/usr/bin/env bash

set -e

# save pwd
pushd `pwd` > /dev/null

SCRIPT_DIR="$( cd "$( dirname "$0" )" && pwd )"
PYTHON_VERSION="$( cut -d '/' -f 1 "${SCRIPT_DIR}"/.python-version )"
PYTHON_BIN=python"$( cut -d '.' -f 1-2 "${SCRIPT_DIR}"/.python-version )"
VIRTUALENV_NAME="$(cut -d '/' -f 3 "${SCRIPT_DIR}"/.python-version)"
"$HOME"/.pyenv/bin/pyenv install --skip-existing "${PYTHON_VERSION}"
"$HOME"/.pyenv/bin/pyenv virtualenv --force --python="${PYTHON_BIN}" "${PYTHON_VERSION}" "${VIRTUALENV_NAME}"
python3 -m pip -q install -r "${SCRIPT_DIR}/requirements.txt"

# restore pwd
popd > /dev/null
python3 "$@"

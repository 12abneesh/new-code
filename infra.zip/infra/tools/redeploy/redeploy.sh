#!/bin/bash
SCRIPT_DIR="$( cd "$( dirname "$0" )" && pwd )"

"${SCRIPT_DIR}"/../python/start_python.sh "${SCRIPT_DIR}"/redeploy.py "$@"

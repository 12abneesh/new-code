from __future__ import annotations

import argparse
import json
import os
import subprocess
import sys
import tempfile
from dataclasses import dataclass

import boto3
from jinja2 import Environment, FileSystemLoader


class Deployment:
    def __init__(
        self,
        template_path: str,
        app_name: str,
        environment: str,
        deploy_type: str,
        region_name: str,
    ):
        self.template_path = template_path
        self.app_name = app_name
        self.environment = environment
        self.deploy_type = deploy_type
        self.region_name = region_name

    def find_latest_image_uri(self) -> str:
        client = boto3.client("ecr", region_name=self.region_name)
        repository_name = f"{self.app_name}-{self.environment}"
        response = client.describe_repositories(repositoryNames=[repository_name])
        if len(response["repositories"]) < 1:
            raise RuntimeError(f"No Repository Found: {self.app_name}")
        respository_uri = response["repositories"][0]["repositoryUri"]

        response = client.describe_images(
            repositoryName=repository_name, imageIds=[{"imageTag": "latest"}]
        )
        if len(response["imageDetails"]) < 1:
            raise RuntimeError(f"No Image Found: {self.app_name}")

        image_tags = response["imageDetails"][0]["imageTags"]
        image_tags.remove("latest")
        image_tag = image_tags[0] if len(image_tags) == 1 else "latest"
        image_uri = f"{respository_uri}:{image_tag}"
        print(f"The latest image is {image_uri}")

        return image_uri

    def render_manifest(self, image_uri: str) -> str:
        template_directory, template_file = os.path.split(self.template_path)
        env = Environment(loader=FileSystemLoader(searchpath=template_directory))
        template = env.get_template(name=template_file)
        rendered = template.render(container_name=self.app_name, image_name=image_uri)
        return rendered

    def deploy_job(self, image_uri: str, manifest: str) -> None:
        # delete the job first if exists
        output = subprocess.run(
            [
                "kubectl",
                "delete",
                f"job/{self.app_name}",
            ],
            capture_output=True,
        )
        print(output.stdout)
        # create new job
        with tempfile.NamedTemporaryFile(mode="w", delete=False) as manifest_tempfile:
            # create new deployment
            manifest_tempfile.write(manifest)
            manifest_tempfile.flush()
            print(f"Temporarily saved the manifest at {manifest_tempfile.name}")
            print(f"Creating a new job for {self.app_name}")
            output = subprocess.run(
                ["kubectl", "apply", "-f", manifest_tempfile.name],
                capture_output=True,
            )
            print(output.stdout)

    def deploy_service(self, image_uri: str, manifest: str) -> None:
        output = subprocess.run(
            ["kubectl", "get", "deployment", self.app_name, "--output", "json"],
            capture_output=True,
        )
        if output.stdout == b"":
            with tempfile.NamedTemporaryFile(
                mode="w", delete=False
            ) as manifest_tempfile:
                # create new deployment
                manifest_tempfile.write(manifest)
                manifest_tempfile.flush()
                print(f"Temporarily saved the manifest at {manifest_tempfile.name}")
                print(f"Creating a new deployment for {self.app_name}")
                output = subprocess.run(
                    ["kubectl", "apply", "-f", manifest_tempfile.name],
                    capture_output=True,
                )
                print(output.stdout)
        else:
            print(f"Updating the deployment for {self.app_name} with image {image_uri}")
            # set the deployment
            output = subprocess.run(
                [
                    "kubectl",
                    "set",
                    "image",
                    f"deployment/{self.app_name}",
                    f"{self.app_name}={image_uri}",
                ],
                capture_output=True,
            )
            print(output.stdout)

    def deploy(self) -> None:
        image_uri = self.find_latest_image_uri()
        manifest = self.render_manifest(image_uri)

        if self.deploy_type.lower() == "service":
            self.deploy_service(image_uri=image_uri, manifest=manifest)
        elif self.deploy_type.lower() == "job":
            self.deploy_job(image_uri=image_uri, manifest=manifest)
        else:
            raise RuntimeError(f"Invalid Deploy Type {self.deploy_type}")


def main() -> int:
    arg_parser = argparse.ArgumentParser()
    arg_parser.add_argument("--template_path", required=True)
    arg_parser.add_argument("--app_name", required=True)
    arg_parser.add_argument("--environment", required=True)
    arg_parser.add_argument("--deploy_type", required=True)
    args = arg_parser.parse_args()
    deployment = Deployment(
        args.template_path,
        args.app_name,
        args.environment,
        args.deploy_type,
        "us-west-2",
    )
    deployment.deploy()


if __name__ == "__main__":
    sys.exit(main())

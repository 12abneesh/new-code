#!/bin/bash


if [ -f .env ]; then
    # Load Environment Variables locally
    export $(cat .env | grep -v '#' | awk '/=/ {print $1}')

    aws s3 --endpoint-url http://localhost:4566 mb s3://$BUCKET_NAME

    aws s3 cp $DATA_DIR s3://$BUCKET_NAME/$DATA_DIR --endpoint-url http://localhost:4566 --recursive

fi

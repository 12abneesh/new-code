Overview:
We have written start.sh which will call docker compose file.
The Docker compose will spin up the following service containers on your local machine.
1-LocalStack - s3 service
2-MSK
3-postgres DB
4-ELK
and application service container .

Pre-requisite:
1- Docker
2- Docker Compose
3- AWS Cli
4- JDK
5- python

Running:

Edit docker compose file to add apllication service rebalncer as per need in docker compose file. 
Edit .env as per your requirement. 
Edit setup.sh as per your requirements for use. (One example is given for create s3 bucket and copy object to s3 bucket.)
we have added a DATA folder. Please add your data to DATA folder which will be added to s3 bucket.

1- Checkout code from repository.
2- Go to locastack directory.--- This will be one time activity to get all scripts.
2- Run ./start sh.

To Stop the containers run ./stop.sh command.

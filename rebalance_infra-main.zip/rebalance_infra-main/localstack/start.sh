#!/bin/bash



date=$(date "+%Y.%m.%d")

localstack=$(docker ps | awk '/localstack/ {print}')

if [[ -z "$localstack" ]]; then
   docker-compose up -d
   if [ $? -eq 0 ]; then
    echo OK
    docker-compose logs >> $date.log
    sleep 10s
    echo "Calling setup script"
    sh setup.sh
   else
    echo "Error: cannot establist connection with docker!!"
   fi
else
   echo "Re-building local enviornment"
   docker-compose down
   sleep 10s
   docker-compose up -d
   sleep 10s
   echo "Calling setup sript"
   sh setup.sh
fi

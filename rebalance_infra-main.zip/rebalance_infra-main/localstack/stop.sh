#!/bin/bash


localstack=$(docker ps -a | awk '/localstack/ {print}')


if [[ -z "$localstack" ]]; then
   echo "Nothing to shutdown"
else
   echo "Shutting down the Local enviornment"
   docker-compose down
   echo "Local enviornment is down!"
fi

